<?php include('index.php'); ?>


<h3>饼形效果_1</h3>
<?php
$code_1='
<script type="text/javascript" src="../js/swfobject.js"></script>
	<div id="flashcontent_1">
		<strong>你需要更新你的FLASH播放器,或联系管理员!</strong>
	</div>
	<script type="text/javascript">
		// <![CDATA[
		var so_1 = new SWFObject("../chart/ampie.swf", "ampie", "520", "400", "8", "#FFFFFF");
		so_1.addVariable("path", "./");//作为下面两个文件的相对路径目录,如果下面为绝对路径则可以不用
		so_1.addVariable("settings_file", encodeURIComponent("ampie_1.xml"));
		so_1.addVariable("data_file", encodeURIComponent("ampie_data.xml"));
		so_1.addVariable("preloader_color", "#999999");
		so_1.write("flashcontent_1");
		// ]]>
	</script>
';

?>
<DIV CLASS="tab-pane" >
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">饼形效果_1</H2>
	  <div><?php echo $code_1; ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">JS代码</H2>
      <div><?php highlight_string ($code_1); ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">设置文件[ampie_1.xml]</H2>
      <div><?php highlight_file ('./ampie_1.xml'); ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">数据文件[ampie_data.xml]</H2>
      <div><?php highlight_file ('./ampie_data.xml'); ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">标准配置[ampie_settings.xml]</H2>
      <div><?php highlight_file ('./ampie_settings.xml'); ?></div>
    </DIV>
  </DIV>

<h3>饼形效果_2</h3>
<?php
$code_2='
<script type="text/javascript" src="../js/swfobject.js"></script>
	<div id="flashcontent_2">
		<strong>你需要更新你的FLASH播放器,或联系管理员!</strong>
	</div>
	<script type="text/javascript">
		// <![CDATA[
		var so_2 = new SWFObject("../chart/ampie.swf", "ampie", "520", "400", "8", "#FFFFFF");
		so_2.addVariable("path", "./");
		so_2.addVariable("settings_file", encodeURIComponent("ampie_2.xml"));
		so_2.addVariable("data_file", encodeURIComponent("ampie_data.xml"));
		so_2.addVariable("preloader_color", "#999999");
		so_2.write("flashcontent_2");
		// ]]>
	</script>
';

?>
<DIV CLASS="tab-pane" >
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">饼形效果_2</H2>
	  <div><?php echo $code_2; ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">JS代码</H2>
      <div><?php highlight_string ($code_2); ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">设置文件[ampie_2.xml]</H2>
      <div><?php highlight_file ('./ampie_2.xml'); ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">数据文件[ampie_data.xml]</H2>
      <div><?php highlight_file ('./ampie_data.xml'); ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">标准配置[ampie_settings.xml]</H2>
      <div><?php highlight_file ('./ampie_settings.xml'); ?></div>
    </DIV>
  </DIV>



<h3>饼形效果_3</h3>
<?php
$code_3='
<script type="text/javascript" src="../js/swfobject.js"></script>
	<div id="flashcontent_3">
		<strong>你需要更新你的FLASH播放器,或联系管理员!</strong>
	</div>
	<script type="text/javascript">
		// <![CDATA[
		var so_3 = new SWFObject("../chart/ampie.swf", "ampie", "400", "350", "2", "#FFFFFF");
		so_3.addVariable("path", "./");
		so_3.addVariable("settings_file", encodeURIComponent("ampie_3.xml"));
		so_3.addVariable("data_file", encodeURIComponent("ampie_data.xml"));
		so_3.addVariable("preloader_color", "#999999");
		so_3.write("flashcontent_3");
		// ]]>
	</script>
';

?>
<DIV CLASS="tab-pane" >
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">饼形效果_3</H2>
	  <div><?php echo $code_3; ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">JS代码</H2>
      <div><?php highlight_string ($code_3); ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">设置文件[ampie_3.xml]</H2>
      <div><?php highlight_file ('./ampie_3.xml'); ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">数据文件[ampie_data.xml]</H2>
      <div><?php highlight_file ('./ampie_data.xml'); ?></div>
    </DIV>
    <DIV CLASS="tab-page" >
      <H2 CLASS="tab">标准配置[ampie_settings.xml]</H2>
      <div><?php highlight_file ('./ampie_settings.xml'); ?></div>
    </DIV>
  </DIV>


<script type="text/javascript">
setupAllTabs();
</script>

</body>
</html>
