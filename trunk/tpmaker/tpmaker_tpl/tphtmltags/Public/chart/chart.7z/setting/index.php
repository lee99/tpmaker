<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title></title>
<link rel="stylesheet" type="text/css" href="/thinkstat/Tpl/default/Public/css/tpmaker.css" />
<link type="text/css" rel="StyleSheet" href="/thinkstat/Tpl/default/Public/css/tab.webfx.css" />

<script type="text/javascript">
var HOST		= window.location.host;
var Per_host	="http://"+HOST;
var JS_PATH		="/thinkstat/Tpl/default/Public/js/";
var IMG_PATH	="/thinkstat/Tpl/default/Public/images/";
var URL			='/thinkstat/index.php/Public';
var APP			='/thinkstat/index.php';
var PUBLIC		='/thinkstat/Tpl/default/Public/';
</script>
<script type="text/javascript" src="/thinkstat/Tpl/default/Public/js/tabpane.js"></script>
</head>
<body>
<table >
	<tr>
	<td >
	<a href="amcolumn_index.php" class="button">比例柱形效果</a>
	<a href="amline_index.php" class="button">波浪对比线形效果</a>
	<a href="ampie_index.php" class="button">饼形效果</a>
	<a href="amradar_index.php" class="button">雷达效果</a>
	<a href="amxy_index.php" class="button">XY轴坐标效果</a>
	</td>
	</tr>
</table>
